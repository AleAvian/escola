package escola;

public class Turma {
	
	Aluno[] alunos;
	
	public double calculaMedia() {
		double total = 0.0;
		
		for (int i = 0; i < this.alunos.length; i++) {
			Aluno alunoDaVez = this.alunos[i]; 
			total += alunoDaVez.nota;
		}
		
		return total / this.alunos.length;
	}
	
	public void imprimeRelatorioDeReprovados() {
		System.out.println("==== RELA��O DE REPROVADOS ====");
		for (int i = 0; i < this.alunos.length; i++) {
			Aluno alunoDaVez = this.alunos[i];
			
			if (alunoDaVez.nota < 5) {
				System.out.println(alunoDaVez.nome + " tirou " + alunoDaVez.nota);
			}
		}
	}
	
}



