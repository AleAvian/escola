package escola;

public class CalculadorDeMedia {

	public static void main(String[] args) {
		Turma flutter = new Turma(); 
		flutter.alunos = new Aluno[5];
		flutter.alunos[0] = new Aluno("ana", 10.0);
		flutter.alunos[1] = new Aluno("bia", 8.9);
		flutter.alunos[2] = new Aluno("caio", 4.5);
		flutter.alunos[3] = new Aluno("dani", 4.8);
		flutter.alunos[4] = new Aluno("eli", 5.0);
		
		System.out.println("M�dia a turma de flutter: " + flutter.calculaMedia());
		flutter.imprimeRelatorioDeReprovados();
	
	}
	
}
